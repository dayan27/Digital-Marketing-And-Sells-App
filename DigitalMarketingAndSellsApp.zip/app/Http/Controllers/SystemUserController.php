<?php

namespace App\Http\Controllers;

use App\Http\Resources\SystemUserResource;
use App\Models\Account;
use App\Models\Manager;
use App\Models\PhoneNumber;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class SystemUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return SystemUserResource::collection(Manager::where('type','system_user')->with('roles')->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $account=Account::create(['user_name'=>$request->email,'password'=>Hash::make($request->last_name.'1234') ]);
        $data=$request->all();
        $data['account_id']=$account->id;
        $data['type']='system_user';
        $manager= Manager::create($data);
       if($manager){
        $phone_numbers=[];
        $phoneNumbers=$request->phone_numbers;
        //return $phoneNumbers;
        foreach($phoneNumbers as $phoneNumber ){
           $phoneNum=new PhoneNumber();
           $phoneNum->phone_number=$phoneNumber;
           $phoneNum->manager_id=$manager->id;

           $phoneNum->save();
           $phone_number['id']=$phoneNum->id;
           $phone_number['phone_number']=$phoneNum->phone_number;
           $phone_numbers[]=$phone_number;

        }
       $manager['phone_numbers']=$phone_numbers;

       }

       $manager->sendEmailVerificationNotification();

       return $manager;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Manager $manager)
    {
        return $manager->update($request->all());

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function assignRoleToEmployee(Request $request,$id){
        $user=Manager::find($id);
        return  $user->assignRole($request->role_id);

    }
}
