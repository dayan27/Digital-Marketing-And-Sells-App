<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserSide\OrderResource;
use App\Models\User;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function getUserOrders($id){
        $user=User::find($id);
        return  OrderResource::collection($user->orders);
    }
}
